import React, { Component } from 'react';

class Carouselex extends Component {
  render() {
    return (
      <div>
        
      </div>
    );
  }
}

export default Carouselex;
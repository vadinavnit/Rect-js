export const baseUrl = "http://localhost:2021/";

// export const ReturnData = (URL,obj) =>
// {
//     let dd = null;
//     const options = {
//         method: 'POST',
//         headers: new Headers({
//             'Content-Type': 'application/json', // <-- Specifying the Content-Type
//         }),
//         body: JSON.stringify(obj),
//     };
//     fetch(URL, options)
//     .then(res => res.json())
//     .then(
//         (result) => {
//             debugger;
//             //this.setState({ data: result.Data, Rowindex: 0, isedit: false })
//             dd = result;
//         },
//         (error) => {

//         }
//     )

//     return dd
// }

export async function commonAPICall (URL,obj) {
    try {
        const options = {
            method: 'POST',
            headers: new Headers({
                'Content-Type': 'application/json', // <-- Specifying the Content-Type
            }),
            body: JSON.stringify(obj),
        };
        debugger;
        const response = await fetch(baseUrl + URL,options);
        const json = await response.json();
      return json
    } catch (err) {
         console.log(err)
      }
 }
import React,{useState,useEffect} from 'react';

function ChiledComponent({action}) {
    const [value, setValue] = useState(0);
    const callbackFunction = useEffect(() =>{
       setValue(action())
    },[action])
  
    return (
      <>
        Chiled : {value}
      </>
    );
  }
  export default ChiledComponent
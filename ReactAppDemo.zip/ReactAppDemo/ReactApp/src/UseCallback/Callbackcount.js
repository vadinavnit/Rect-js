import React,{useState,useCallback} from 'react';
import ChiledComponent from './ChiledComponent';



function Callbackcount() {
    const [callbackcount, setcallbackcount] = useState(0);

    const callbackFunction = useCallback(() =>{
        console.log(callbackcount);
        return callbackcount
        
    },[callbackcount])
  
    return (
      <>
        <ChiledComponent action={callbackFunction} />
        <button onClick={() => setcallbackcount(callbackcount + 1)}>click</button>
      </>
    );
  }
  
  export default  Callbackcount
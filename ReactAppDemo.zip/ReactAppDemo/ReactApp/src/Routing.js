import React, { Component } from 'react';
import Menu from './Menu';
import Contact from './Contact';
import About from './About';
import Home from './Home';
import MouseTracker from './RenderProps/MouseTracker';
import Contctwithhook from './Contctwithhook';
import Ref from './Ref';
import Navnit from './HOC/Navnit';
import Counter from './UseReducer/Counter';
import Callbackcount from './UseCallback/Callbackcount';
import { BrowserRouter, Route, Switch } from 'react-router-dom';
import FomicForm from './Validation/FomicForm';
import Carouselex from './Carousel/Carouselex';
import Hook from './Hook/Hook';
import Login from './Login';
import PageNotFound from './PageNotFound';

class Routing extends Component {
  render() {
    return (
      <div className="App">
        {/* <Home /> */}
        <BrowserRouter>
          {localStorage.getItem('userData') === null &&
           <Login />
          }
          {localStorage.getItem('userData') !== null && (
            <div>
              <Menu />
              <Switch>
                <Route path="/home" exact component={Home} />
                <Route
                  path="/about"
                  render={props => <About {...props} name="Navnit" />}
                />
                {/* <Route path='/' component={Login} /> */}
                <Route path="/contact" component={Contact} />
                <Route path="/contactwithhook" component={Contctwithhook} />
                <Route path="/mousetracker" component={MouseTracker} />
                <Route path="/ref" component={Ref} />
                <Route path="/hoc" component={Navnit} />
                <Route path="/reducer" component={Counter} />
                <Route path="/callback" component={Callbackcount} />
                <Route path="/formvalidation" component={FomicForm} />
                <Route path="/carousel" component={Carouselex} />
                <Route path="/hook" component={Hook} />
                <Route path="*" component={PageNotFound} />
                {/* <Route render={props => (<NotFoundRoute path={`*`}    />)} /> */}
              </Switch>
            </div>
          )}
        </BrowserRouter>
      </div>
    );
  }
}
export default Routing;

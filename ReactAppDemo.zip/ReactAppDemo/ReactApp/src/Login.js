import React from "react";
import { ErrorMessage, Formik } from 'formik';
import * as Yup from 'yup';
import { baseUrl, ReturnData } from './BaseFile';

import { useHistory } from 'react-router-dom';


const validationSchema = Yup.object().shape({
email : Yup.string()
.max(255,"Must have shorter than 255")
.required("Required"),
password: Yup.string()
        .min(2, 'Too Short!')
        .max(50, 'Too Long!')
        .required('Required')
})

function Login(props) {
    const history = useHistory();
    return (
        <div className="container">
            <Formik initialValues={{  email:"",password:""}} validationSchema={validationSchema}
            onSubmit={(values, { setSubmitting, resetForm }) => {
                debugger;
                setSubmitting(true);
                setTimeout(() => {
                    // alert(JSON.stringify(values, null, 2));
                    const obj = {
                        Token: '123',
                        UserName: values.email,
                        Password: values.password,
                    }
                    const URL = baseUrl + "Login"
                    const options = {
                        method: 'POST',
                        headers: new Headers({
                            'Content-Type': 'application/json', // <-- Specifying the Content-Type
                        }),
                        body: JSON.stringify(obj),
                    };
                    fetch(URL, options)
                        .then(res => res.json())
                        .then(
                            (result) => {
                                if (result.ReturnCode == 1) {
                                    debugger;   
                                    localStorage.setItem("userData", JSON.stringify(result.Data))
                                    window.location.href = '/home'
                                }
                                else
                                {
                                    alert('user name and password doese not match')
                                }
                            },
                            (error) => {
    
                            }
                        )
                    setSubmitting(false);
                }, 500);
            }}
            >
                {({ values, errors, touched, handleChange, handleBlur, handleSubmit, isSubmitting }) => (
                    <form onSubmit={handleSubmit}>
                        <div>
                            <label>Email</label>
                            <input className={touched.email && errors.email ? "has-error" : null} type="text" name="email" id="email" placeholder="Enter your email" onChange={handleChange} onBlur={handleBlur} value={values.email}></input>
                            <ErrorMessage className="errorcls" name="email" component="div"></ErrorMessage>
                        </div>
                        <div>
                            <label>Passwords</label>
                            <input className={touched.password && errors.password ? "has-error" : null} type="password" name="password" id="password" placeholder="Enter your password" onChange={handleChange} onBlur={handleBlur} value={values.password}></input>
                            <ErrorMessage className="errorcls" name="password" component="div"></ErrorMessage>
                        </div>
                        <div>
                            <input type="submit" disabled={isSubmitting} id="btnsubmit" value="Login" />
                        </div>
                    </form>
                )}
            </Formik>
        </div>
    )
}
export default Login
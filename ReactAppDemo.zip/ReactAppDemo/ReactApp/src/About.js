import React, { Component } from 'react';

// const About = () =>
// {
//     return(
//         <div>
//             <h2>Wel Come To About Page !</h2>
//         </div>
//         );
// }

// -------react lifecycle-----------

class About extends Component {
    constructor(props) {
        super(props)
        this.state = {
            text: ''
        }
        console.log("Constructor 1");
        console.log(this.props.name);
        
    }
    clickme = (event) => {
        this.setState({ text: 'test' })
        alert(JSON.stringify(this.state))
    }
    render() {
        console.log("Render 3");
        return (
            <div>
                <h2>Wel Come To About Page  React lifecycle Demo!</h2>
                <button className="btn btn-primary" onClick={this.clickme} >Click</button>
            </div>
            
        );
    }
    shouldComponentUpdate() {
        return true;
        //return true OR false
    }
    componentDidMount() {
        console.log("Did Mounted 4"); // hear api call
    }
    componentDidUpdate(prevProps, prevState, snapshot) {
        console.log("Did Update 5"); // when state update
    }
    componentWillMount() {
        console.log("Will Mounted 2");
        //this.props.CallContactMethod()
    }
    // getSnapshotBeforeUpdate(prevProps, prevState)
    // {
    //     console.log("get snapshot before update");
    // }
    componentWillUnmount() {
        console.log("Will Unmount");
    }
    // componentWillReceiveProps()
    // {
    //     console.log("componentWillReceiveProps");
    // }
    // static getDerivedStateFromProps(props, state)
    // {
    //     console.log(props);
    //     console.log(state);
    //     //call afer constructor
    // }
    // componentDidCatch(error, info) {
    //     console.log(`Error log from componentDidCatch: ${error}`);
    //     console.log(info);
    //   }


}

export default About;
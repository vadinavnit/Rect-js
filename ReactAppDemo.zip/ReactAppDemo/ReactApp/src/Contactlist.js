import React, { Component } from 'react';
import './Contactlist.css'

class Contactlist extends Component {
    constructor(props) {
        super(props)
        this.state = {
            data: this.props.location.state.Statedata.data,
            formf: {
                firstname: '',
                lastname: '',
                country: '',
                subject: ''
            },
            message: 'No Data Found',
            Rowindex: '',
        }
    }
    render() {
        return (
            <div>
                <h1>WelCome to Contact List</h1>
                <table>
                    <tbody>
                        <tr>
                            <th>ID</th>
                            <th>First name</th>
                            <th>Last Name</th>
                            <th>Country</th>
                            <th>Subject</th>
                            <th>Action</th>
                        </tr>
                        {
                            this.state.data.length > 0 && this.state.data.map((item, index) => (
                                <tr key={index}>
                                    <td>{index}</td>
                                    <td>{item.firstname}</td>
                                    <td>{item.lastname}</td>
                                    <td>{item.country}</td>
                                    <td>{item.subject}</td>
                                    <td><button onClick={(event) => this.DeleteRow(index)} className="button button3">Delete</button> <button onClick={(event) => this.EditRow(index)} className="button">Edit</button></td>
                                </tr>
                            ))
                        }
                        {
                            this.state.data.length === 0 && (
                                <tr>
                                    <td className="textcenter" colSpan="6">{this.state.message}</td>
                                </tr>
                            )
                        }
                    </tbody>
                </table>

            </div>
        );
    }
}
export default Contactlist;

import React from 'react';

class Cat extends React.Component {
    
    render() {
        console.log('cat');

      const mouse = this.props.mouse;
      return (

        <p>The current mouse position is ({mouse.x}, {mouse.y})</p>
        // <img src="/cat.jpg" style={{ position: 'absolute', left: mouse.x, top: mouse.y }} />
      );
    }
  }
  export default Cat; 
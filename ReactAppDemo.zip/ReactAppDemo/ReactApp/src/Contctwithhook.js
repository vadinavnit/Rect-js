import React, { useEffect, useState,useContext } from 'react';
import { myContext } from './Context/Context';


function Contctwithhook(props) {
  const contextValue = useContext(myContext);
  console.log(contextValue);
  // Declare a new state variable, which we'll call "count"
  // const [name, setName] = useState("Navnit");
  // const [surname, setSurname] = useState("Vadi");
  //props.history.push("/");
  const name = useFormInput("Navnit");
  const surname = useFormInput("Vadi");

  const width = UseWindowWidth();
  useDocumentTitle(name.value + ' | ' + surname.value)
  // useEffect(() => {
  //   //console.log('2');
  //   // Update the document title using the browser API
  //   document.title = `${name} | ${surname}`;
  // });

  // useEffect(() => {

  //     const handleResize = () =>
  //     {
  //       setWidth(window.innerWidth);
  //     }
  //     window.addEventListener('resize',handleResize)
  //     return () =>
  //     {
  //       window.removeEventListener('resize',handleResize)
  //     }
  // })

  // function handleNameChanege(e)
  // {
  //   setName(e.target.value)
  // }

  // function handleSurnameChanege(e)
  // {
  //   setSurname(e.target.value)
  // }


  return (
    <div className="container">
      {/* <p>You clicked {count} times</p>
      <button onClick={() => setCount(count + 1)}>
        Click me
      </button> */}
      {/* <input onChange={handleNameChanege} type="text" value={name} ></input>
      <input onChange={handleSurnameChanege} type="text" value={surname} ></input> */}

      <input type="text" {...name} ></input>
      <input type="text" {...surname} ></input>
      <div>{width}</div>
    </div>
  );
}


function useFormInput(initialValue) {
  const [value, setValue] = useState(initialValue);
  function handleChanege(e) {
    setValue(e.target.value)
  }
  return {
    value,
    onChange: handleChanege
  };
}
function useDocumentTitle(title) {
  useEffect(() => {
    //console.log('2');
    // Update the document title using the browser API
    document.title = title;
  });

}

function UseWindowWidth() {
  const [width, setWidth] = useState(window.innerWidth);
  useEffect(() => {
    const handleResize = () => {
      setWidth(window.innerWidth);
    }
    window.addEventListener('resize', handleResize)

    return () => {
      window.removeEventListener('resize', handleResize)
    }
  })
  return width;
}

export default Contctwithhook;
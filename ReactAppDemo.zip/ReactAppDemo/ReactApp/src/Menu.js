import React from 'react';
import { Link, NavLink } from 'react-router-dom';
import './Menu.css'

// ---------------- using function

const Menu = () => {
   const logOut = () =>
   {
    localStorage.clear();
    window.location.href = '/';   
   }

    return (
        <div className="topnav">
            <NavLink to="home">Home |</NavLink>
            <NavLink to="contact">Contact |</NavLink>
            <NavLink to="about">About |</NavLink>
            <NavLink to="contactwithhook">Component Hook |</NavLink>
            <NavLink to="mousetracker">RenderProps |</NavLink> 
            <NavLink to="ref">Ref |</NavLink>
            <NavLink to="hoc">HOC |</NavLink>
            <NavLink to="reducer">UseReducer |</NavLink>
            <NavLink to="callback">Callback |</NavLink>
            <NavLink to="formvalidation">Validation |</NavLink>
            <NavLink to="carousel">Carousel |</NavLink>
            <NavLink to="hook">Hook |</NavLink>
            <a href="#" onClick={logOut}>Logout</a>
            {/* <Link to="contactlist">Contact List</Link> */}
        </div>
    );
}

// ---------------- using class

// class Menu extends Comment{
//     render()
//         {
//         return(
//         <div className="topnav">
//             <a className="active" href="#home">Home</a>
//             <a href="#">News</a>
//             <a href="#">Contact</a>
//             <a href="#">About</a>
//         </div>
//         )
//     }
// }
export default Menu;
import React, { useEffect, useState, useContext } from 'react';
import './Hook.css';
import { baseUrl, commonAPICall } from '../BaseFile';


function Hook(props) {

  const initialFormState = { firstname: '', lastname: '',country: '',subject: '' }
  const [user, setUser] = useState(initialFormState);
  const [data, setData] = useState([]);  
  const [Rowindex, setRowindex] = useState(0)

    useEffect(()=> {
        GetData();  
    }, []);

  const handleInputChange = (event) => {
      debugger;
    const { name, value } = event.target

    setUser({ ...user, [name]: value })
  }
  const InsertUpdate = (e) =>
  {
    e.preventDefault(); 

    const obj = {
        APIKey: '123',
        ID: Rowindex,
        Name: user.firstname,
        LastName: user.lastname,
        Country: user.country,
        Subject:  user.subject,
    }
    const URL = baseUrl + "InsertUpdateContact"
    const options = {
        method: 'POST',
        headers: new Headers({
            'Content-Type': 'application/json', // <-- Specifying the Content-Type
        }),
        body: JSON.stringify(obj),
    };
    fetch(URL, options)
        .then(res => res.json())
        .then(
            (result) => {
                if (result.ReturnCode == 1) {
                    GetData();
                }
            },
            (error) => {

            }
        )
  }
 const  GetData  = async () => {
    const obj = {
        APIKey: '123'
    }
    const URL = "ContactGetData"
    const result = await commonAPICall(URL, obj)
    if (result.ReturnCode == 1) {
        setData(result.Data);  
    }
}

const DeleteRecord = () => {
    const obj = {
        APIKey: '123',
        ID: Rowindex,
    }
    const URL = baseUrl + "DeleteContact"
    const options = {
        method: 'POST',
        headers: new Headers({
            'Content-Type': 'application/json', // <-- Specifying the Content-Type
        }),
        body: JSON.stringify(obj),
    };
    fetch(URL, options)
        .then(res => res.json())
        .then(
            (result) => {
                if (result.ReturnCode == 1) {
                    GetData();
                }
            },
            (error) => {
            })
}
const DeleteConfirmation = (Rowindex) => {
    const arrobj = data.find(element => element.Rowindex === Rowindex);
    setRowindex(Rowindex);
}
const EditRow = (Rowindex) => {
    let arrEdit = [...data].filter((item, i) => {
        return item.Rowindex === Rowindex
    })
    setUser({ ...user, firstname : arrEdit[0].firstname, lastname : arrEdit[0].lastname, subject : arrEdit[0].subject, country : arrEdit[0].country })
    setRowindex(Rowindex);
}

  return (
    <div className="container">
      <form onSubmit={InsertUpdate}>
        <h1>Register</h1>
        <p>Please fill in this form to create an account.</p>
        <hr />

        <label htmlFor="fname">
          <b>First Name</b>
        </label>
        <input type="text" onChange={handleInputChange} value={user.firstname} placeholder="First Name" name="firstname" />

        <label htmlFor="lname">
          <b>Last Name</b>
        </label>
        <input
          type="text" value={user.lastname} onChange={handleInputChange}
          placeholder="Last Name"
          name="lastname"
        />
           <label htmlFor="country">Country</label>
                        <select value={user.country} onChange={handleInputChange} id="country" name="country">
                            <option value="">--select--</option>
                            <option value="australia">Australia</option>
                            <option value="canada">Canada</option>
                            <option value="usa">USA</option>
                        </select>

       <label htmlFor="subject">Subject</label>
                        <textarea onChange={handleInputChange} value={user.subject} id="subject" name="subject" placeholder="Write something.." style={{ height: '50px' }}></textarea>
        <hr />
        <button type="submit" className="registerbtn">
          Register
        </button>
      </form>
                    <table>
                        <tbody>
                            <tr>
                                <th>First name</th>
                                <th>Last Name</th>
                                <th>Country</th>
                                <th>Subject</th>
                                <th>Action</th>
                            </tr>
                            {
                            data.map((item, index) => (
                                    <tr key={index}>
                                        <td>{item.firstname}</td>
                                        <td>{item.lastname}</td>
                                        <td>{item.country}</td>
                                        <td>{item.subject}</td>
                                        <td><button data-toggle="modal" data-target="#exampleModal" onClick={(event) => DeleteConfirmation(item.Rowindex)} className="button button3">Delete</button> <button onClick={(event) => EditRow(item.Rowindex)} className="button">Edit</button></td>
                                    </tr>
                            ))
                        }
                             {
                                data.length === 0 && (
                                    <tr>
                                        <td className="textcenter" colSpan="5">No record found</td>
                                    </tr>
                                )
                            }
                        </tbody>
                    </table>
                    <div className="modal fade" id="exampleModal" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                    <div className="modal-dialog" role="document">
                        <div className="modal-content">
                            <div className="modal-header">
                                <h5 className="modal-title" id="exampleModalLabel">Delete Confirmation</h5>
                                <button type="button" className="close" data-dismiss="modal" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                </button>
                            </div>
                            <div className="modal-body">
                                <h6>Are your sure you want to delete? </h6>
                            </div>
                            <div className="modal-footer">
                                <button type="button" className="btn btn-secondary" data-dismiss="modal">Close</button>
                                <button type="button" onClick={DeleteRecord} className="btn btn-primary">Yes</button>
                            </div>
                        </div>
                    </div>
                </div>
    </div>

  );
}

export default Hook;

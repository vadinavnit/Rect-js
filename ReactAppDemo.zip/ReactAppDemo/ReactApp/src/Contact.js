import React, { Component } from 'react';
import './Contact.css'
import { Consumer } from './Context/Context';
import { baseUrl, commonAPICall } from './BaseFile';
// import About from './About'

//const emailRegex = RegExp(/^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/)
// const formValid = ({ formErrors, ...rest }) => {
//     let valid = true;
//     // validate form errors being empty
//     Object.values(formErrors).forEach(val => {
//         val.length > 0 && (valid = false);
//     });
//     // validate the form was filled out
//     Object.values(rest).forEach(val => {
//         val === null && (valid = false);
//     });
//     return valid;
// };

class Contact extends Component {

    constructor(props) {
        super(props)
        this.state = {
            data: [],
            formf: {
                firstname: '',
                lastname: '',
                country: '',
                subject: ''
            },
            message: 'No Data Found',
            Rowindex: 0,
            firstname: '',
            isedit: false,
            formErrors:
            {
                firstname: '',
                lastname: '',
                country: '',
                subject: ''
            }
        }
        this.DeleteRecord = this.DeleteRecord.bind(this);
    }
    // CallFromAbout()
    // {
    //     alert("Call From About");Reactjs code snippets
    // }
    async GetData() {
        const obj = {
            Token: '123'
        }
        const URL = "ContactGetData"
        // const options = {
        //     method: 'POST',
        //     headers: new Headers({
        //         'Content-Type': 'application/json', // <-- Specifying the Content-Type
        //     }),
        //     body: JSON.stringify(obj),
        // };
        // fetch(URL, options)
        //     .then(res => res.json())
        //     .then(
        //         (result) => {
        //             this.setState({ data: result.Data, Rowindex: 0, isedit: false })
        //         },
        //         (error) => {

        //         }
        //     )
        const result = await commonAPICall(URL, obj)
        if (result.ReturnCode == 1) {
            this.setState({ data: result.Data, Rowindex: 0, isedit: false })
        }
    }
    componentDidMount() {
        this.GetData();
    }
    HandleKey = (event) => {
        const { name, value } = event.target;
        let formErrors = { ...this.state.formErrors };
        switch (name) {
            case "firstname":
                formErrors.firstname = value.length < 5 && value.length > 0 ? "minimum 5 character required" : "";
                break;
            case "lastname":
                formErrors.lastname = value.length < 5 && value.length > 0 ? "minimum 5 character required" : "";
                break;
            case "subject":
                formErrors.subject = value.length < 5 && value.length > 0 ? "minimum 5 character required" : "";
                break;
            default:
                break;
        }
        this.setState({ formf: { ...this.state.formf, [event.target.name]: event.target.value }, formErrors, [name]: value }, () => console.log(this.state))
    }

    validate = () => {
        const { firstname, lastname, country, subject } = this.state.formf //distruction in es6
        let formErrors = this.state.formErrors;

        var efirstname = "";
        let elastname = "";
        let ecountry = "";
        let esubject = "";
        if (!firstname) {
            efirstname = "required";
        }
        if (formErrors.firstname) {
            efirstname = formErrors.firstname;
        }
        if (!lastname) {
            elastname = "required";
        }
        if (formErrors.lastname) {
            elastname = formErrors.lastname;
        }
        if (!country) {
            ecountry = "required";
        }
        if (formErrors.country) {
            ecountry = formErrors.country;
        }
        if (!subject) {
            esubject = "required";
        }
        if (formErrors.subject) {
            esubject = formErrors.subject;
        }
        if (efirstname || elastname || ecountry || esubject) {
            this.setState({ formErrors: { firstname: efirstname, lastname: elastname, country: ecountry, subject: esubject } })
            return false;
        }
        return true
    }
    handlesubmit = (event) => {
        //`${this.state.firstname}`
        event.preventDefault();
        const { firstname, lastname, country, subject } = this.state.formf //distruction in es6
        const isValid = this.validate();
        if (isValid) {
            // if (formValid(this.state)) {
            //     console.error("FORM VALID");
            //   } else {
            //     console.error("FORM INVALID - DISPLAY ERROR MESSAGE");
            //   }
            //if (firstname !== "" && lastname !== "" && country !== "" && subject !== "") {
            //this.setState({ ...this.state, data: [...this.state.data, this.state.formf] })
            //this.setState({data: [...this.state.data, this.state.formf] })
            // this.setState({...this.state,  formf : {firstname: ''} });
            if (this.state.isedit === true) {
                // const arrEdit = [...this.state.data]
                // for (let i = 0; i < arrEdit.length; i++) {
                //     if (i === this.state.Rowindex) {
                //         arrEdit[i].firstname = this.state.formf.firstname;
                //         arrEdit[i].lastname = this.state.formf.lastname;
                //         arrEdit[i].country = this.state.formf.country;
                //         arrEdit[i].subject = this.state.formf.subject;
                //     }
                // }
                // this.setState({ data: arrEdit, formf: { firstname: '', lastname: '', country: '', subject: '' }, Rowindex: 0 })
                const obj = {
                    Token: '123',
                    ID: this.state.Rowindex,
                    Name: firstname,
                    LastName: lastname,
                    Country: country,
                    Subject: subject,
                }
                const URL = baseUrl + "InsertUpdateContact"
                const options = {
                    method: 'POST',
                    headers: new Headers({
                        'Content-Type': 'application/json', // <-- Specifying the Content-Type
                    }),
                    body: JSON.stringify(obj),
                };
                fetch(URL, options)
                    .then(res => res.json())
                    .then(
                        (result) => {
                            if (result.ReturnCode == 1) {
                                this.GetData();
                                this.setState({ formf: { firstname: '', lastname: '', country: '', subject: '' } })
                            }
                            //this.setState({data :result.Data})
                        },
                        (error) => {
                        }
                    )
            }
            else {
                const obj = {
                    Token: '123',
                    ID: this.state.Rowindex,
                    Name: firstname,
                    LastName: lastname,
                    Country: country,
                    Subject: subject,
                }
                const URL = baseUrl + "InsertUpdateContact"
                const options = {
                    method: 'POST',
                    headers: new Headers({
                        'Content-Type': 'application/json', // <-- Specifying the Content-Type
                    }),
                    body: JSON.stringify(obj),
                };
                fetch(URL, options)
                    .then(res => res.json())
                    .then(
                        (result) => {
                            if (result.ReturnCode == 1) {
                                this.GetData();
                                this.setState({ formf: { firstname: '', lastname: '', country: '', subject: '' } })
                            }
                            //this.setState({data :result.Data})
                        },
                        (error) => {

                        }
                    )
                // this.setState({ data: [...this.state.data, this.state.formf], formf: { firstname: '', lastname: '', country: '', subject: '' } },
                // ()=>{
                // Pass State Data to Contactlist
                //     //this.props.history.push('/Contactlist',{ Statedata: this.state})
                // })
            }
            //}
        }
        else {
        }
        //this.props.history.push('about'); 
    }
    ColseModal = () => {
        this.setState({ firstname: "", Rowindex: 0 })
    }
    DeleteConfirmation(Rowindex) {
        // var array = [...this.state.data]; // make a separate copy of the array
        // if (index !== -1) {
        //     array.splice(index, 1);
        //     this.setState({ data: [...array] })
        // }
        const arrobj = this.state.data.find(element => element.Rowindex === Rowindex);
        this.setState({ firstname: arrobj.firstname, Rowindex: Rowindex })
    }
    DeleteRecord() {
        const obj = {
            Token: '123',
            ID: this.state.Rowindex,
        }
        const URL = baseUrl + "DeleteContact"
        const options = {
            method: 'POST',
            headers: new Headers({
                'Content-Type': 'application/json', // <-- Specifying the Content-Type
            }),
            body: JSON.stringify(obj),
        };
        fetch(URL, options)
            .then(res => res.json())
            .then(
                (result) => {
                    if (result.ReturnCode == 1) {
                        this.GetData();
                    }
                    //this.setState({data :result.Data})
                },
                (error) => {

                })
    }
    // CallFromParent()
    // {
    //     alert('hi');
    //     throw new Error('I crashed!');
    // }
    EditRow(Rowindex) {
        let arrEdit = [...this.state.data].filter((item, i) => {
            //return i == index
            return item.Rowindex === Rowindex
        })
        this.setState({ formf: { firstname: arrEdit[0].firstname, lastname: arrEdit[0].lastname, country: arrEdit[0].country, subject: arrEdit[0].subject }, Rowindex: Rowindex, isedit: true })
        //$("#btnsubmit").val("Update")
    }
    Clearall() {
        this.setState({ data: [], message: 'No Data Found' })
    }
    // inputDecimal(e)
    // {
    //     if((e.which != 46 || e.target.value.indexOf('.') != -1 ) && (e.which < 48 || e.which > 57))
    //     {
    //         e.preventDefault()
    //     }
    // }
    render() {
        const { formErrors } = this.state;
        let theme = this.context;
        return (

            <div className="container">
                <Consumer>
                    {({ data, handleClick }) =>
                        (
                            <div>
                                <h4>User Name :  {data.username} </h4>
                                <button onClick={handleClick}>Click Context Function</button>
                            </div>
                        )}
                </Consumer>
                <div className="modal fade" id="exampleModal" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                    <div className="modal-dialog" role="document">
                        <div className="modal-content">
                            <div className="modal-header">
                                <h5 className="modal-title" id="exampleModalLabel">Delete Confirmation</h5>
                                <button type="button" className="close" data-dismiss="modal" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                </button>
                            </div>
                            <div className="modal-body">
                                <h6>Are your sure you want to delete  {this.state.firstname} ? </h6>
                            </div>
                            <div className="modal-footer">
                                <button type="button" onClick={this.ColseModal} className="btn btn-secondary" data-dismiss="modal">Close</button>
                                <button type="button" onClick={this.DeleteRecord} className="btn btn-primary">Yes</button>
                            </div>
                        </div>
                    </div>
                </div>
                {/* <About CallContactMethod = {this.CallFromAbout.bind(this)} /> */}
                <div>
                    <form onSubmit={this.handlesubmit}>
                        <label htmlFor="fname">First Name</label>
                        {/* <input type="text" id="fname" name="firstname" onChange={(event) => this.HandleKey(event)} placeholder="Your name.." value={this.state.firstname} /> */}
                        <input type="text" className={formErrors.firstname.length > 0 ? "error" : null} id="fname" name="firstname" onChange={this.HandleKey} placeholder="Your name.." value={this.state.formf.firstname} />
                        <div style={{ textAlign: 'left' }}>{formErrors.firstname.length > 0 && (
                            <span className="errorMessage">{formErrors.firstname}</span>
                        )}</div>
                        <label htmlFor="lname">Last Name</label>
                        <input type="text" className={formErrors.lastname.length > 0 ? "error" : null} id="lname" name="lastname" onChange={this.HandleKey} placeholder="Your last name.." value={this.state.formf.lastname} />
                        <div style={{ textAlign: 'left' }}>{formErrors.lastname.length > 0 && (
                            <span className="errorMessage">{formErrors.lastname}</span>
                        )}</div>
                        <label htmlFor="country">Country</label>
                        <select id="country" className={formErrors.country.length > 0 ? "error" : null} name="country" onChange={this.HandleKey} value={this.state.formf.country}>
                            <option value="">--select--</option>
                            <option value="australia">Australia</option>
                            <option value="canada">Canada</option>
                            <option value="usa">USA</option>
                        </select>
                        <div style={{ textAlign: 'left' }}>{formErrors.country.length > 0 && (
                            <span className="errorMessage">{formErrors.country}</span>
                        )}</div>
                        <label htmlFor="subject">Subject</label>
                        <textarea id="subject" className={formErrors.subject.length > 0 ? "error" : null} name="subject" onChange={this.HandleKey} placeholder="Write something.." style={{ height: '50px' }} value={this.state.formf.subject}></textarea>
                        <div style={{ textAlign: 'left' }}>{formErrors.subject.length > 0 && (
                            <span className="errorMessage">{formErrors.subject}</span>
                        )}</div>
                        <span id="spd"></span>
                        <input type="submit" id="btnsubmit" value={this.state.isedit === false ? "Add" : "Update"} />
                    </form>
                </div>
                <div>
                    {
                        this.state.data.length > 0 && <button style={{ float: 'left' }} onClick={() => this.Clearall()} className="button button3">Clear All</button>
                    }
                    <table>
                        <tbody>
                            <tr>
                                <th>First name</th>
                                <th>Last Name</th>
                                <th>Country</th>
                                <th>Subject</th>
                                <th>Action</th>
                            </tr>
                            {
                                this.state.data.length > 0 && this.state.data.map((item, index) => (
                                    <tr key={index}>
                                        <td>{item.firstname}</td>
                                        <td>{item.lastname}</td>
                                        <td>{item.country}</td>
                                        <td>{item.subject}</td>
                                        <td><button data-toggle="modal" data-target="#exampleModal" onClick={(event) => this.DeleteConfirmation(item.Rowindex)} className="button button3">Delete</button> <button onClick={(event) => this.EditRow(item.Rowindex)} className="button">Edit</button></td>
                                    </tr>
                                ))
                            }
                            {
                                this.state.data.length === 0 && (
                                    <tr>
                                        <td className="textcenter" colSpan="5">{this.state.message}</td>
                                    </tr>
                                )
                            }
                        </tbody>
                    </table>
                </div>
            </div>
        );
    }
}
//Contact.contextType = myContext;
export default Contact;
//export default withUserContext(Contact);
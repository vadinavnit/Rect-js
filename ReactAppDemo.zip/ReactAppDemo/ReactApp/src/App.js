import React, { Component } from 'react';
import './App.css';
import Routing from './Routing';
//import Home from './PropState/Home';
import { Provider } from './Context/Context';

class App extends Component {
  state = {
    username: 'Navnit'
  };
  handleClickContext = () => {
    alert('Call Context Method');
  };
  render() {
    const ContextValue = {
      data: this.state,
      handleClick: this.handleClickContext
    };
    return (
      <div className="App">
        {/* <Home /> */}
        <Provider value={ContextValue}>
          <Routing />
        </Provider>
      </div>
    );
  }
  componentDidMount() {
    this.props.hideLoader();
  }
}
export default App;

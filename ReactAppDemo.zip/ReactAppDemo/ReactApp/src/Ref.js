import React, { Component } from 'react'

class Ref extends Component {
    constructor(props) {
        super(props)
        this.refAdd = null;
        this.setRef = (element) => {
            this.refAdd = element
        }
    }
    keyup(e, target) {
        if (e.keyCode === 13) {
            switch (target) {
                case "Fname":
                    this.Lname.focus();
                    break;
                case "Lname":
                    this.Age.focus();
                    break;
                default:
                    break;
            }
        }
    }
    componentDidMount() {
        if (this.refAdd) {
            this.refAdd.focus();
        }
    }

    render() {
        return (
            <div className="container">
                <div>
                    <span>First Name</span>
                    <input onKeyUp={(e) => this.keyup(e, "Fname")} type="text" ref={(input) => { this.Fname = input }}></input>
                </div>
                <div>
                    <span>Last Name</span>
                    <input onKeyUp={(e) => this.keyup(e, "Lname")} type="text" ref={(input) => { this.Lname = input }}></input>
                </div>
                <div>
                    <span>Age</span>
                    <input onKeyUp={(e) => this.keyup(e, "Age")} type="text" ref={(input) => { this.Lname = input }}></input>
                    <span>Address</span>
                    <input type="text" ref={this.setRef}></input>
                </div>
            </div>
        );
    }
}
export default Ref
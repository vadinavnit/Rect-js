import React from "react";
import { ErrorMessage, Formik } from 'formik';
import * as Yup from 'yup';

const number = /^[0-9]*$/;

const validationSchema = Yup.object().shape({
name : Yup.string()
.min(2,"Must have a charactert")
.max(255,"Must have shorter than 255")
.required("Must enter a name"),

email : Yup.string()
.email("Must be a valid email address")
.max(255,"Must have shorter than 255")
.required("Must enter a email"),

password: Yup.string()
        .min(2, 'Too Short!')
        .max(50, 'Too Long!')
        .required('Required'),
    cpassword: Yup.string()
        .required('Required')
        .oneOf([Yup.ref('password'), null], 'Passwords do not match'),
        mobile: Yup.string()
        .matches(number, {message: "Enter Valid Number", excludeEmptyString: true })
        .required("Required")
        .max(12,"Too Long!"),

    term: Yup.bool()
      .test(
        'term',
        'You have to agree with our Terms and Conditions!',
        value => value === true
      )
      .required(
        'You have to agree with our Terms and Conditions!'
      ),

})

function FomicForm() {
    return (
        <div className="container">
            <Formik initialValues={{ name: "", email:"",password:"",cpassword:"",mobile:"" ,term : false}} validationSchema={validationSchema}
            onSubmit={(values, { setSubmitting, resetForm }) => {
                debugger;
                setSubmitting(true);
                setTimeout(() => {
                    alert(JSON.stringify(values, null, 2));
                    setSubmitting(false);
                }, 500);
            }}
            >
                {({ values, errors, touched, handleChange, handleBlur, handleSubmit, isSubmitting }) => (
                    <form onSubmit={handleSubmit}>
                        {JSON.stringify(values)}
                        {JSON.stringify(isSubmitting)}
                        <div>
                            <label>Name</label>
                            <input className={touched.name && errors.name ? "has-error" : null} type="text" name="name" id="name" placeholder="enter your name" onChange={handleChange} onBlur={handleBlur} value={values.name}></input>
                            <ErrorMessage className="errorcls" name="name" component="div"></ErrorMessage>
                        </div>
                        <div>
                            <label>Email</label>
                            <input className={touched.email && errors.email ? "has-error" : null} type="text" name="email" id="email" placeholder="enter your email" onChange={handleChange} onBlur={handleBlur} value={values.email}></input>
                            <ErrorMessage className="errorcls" name="email" component="div"></ErrorMessage>
                        </div>
                        <div>
                            <label>Passwords</label>
                            <input className={touched.password && errors.password ? "has-error" : null} type="text" name="password" id="password" placeholder="enter your password" onChange={handleChange} onBlur={handleBlur} value={values.password}></input>
                            <ErrorMessage className="errorcls" name="password" component="div"></ErrorMessage>
                        </div>
                        <div>
                            <label>Cpassword</label>
                            <input className={touched.cpassword && errors.cpassword ? "has-error" : null} type="text" name="cpassword" id="cpassword" placeholder="enter your cpassword" onChange={handleChange} onBlur={handleBlur} value={values.cpassword}></input>
                            <ErrorMessage className="errorcls" name="cpassword" component="div"></ErrorMessage>
                        </div>
                        <div>
                            <label>Mobile</label>
                            <input className={touched.mobile && errors.mobile ? "has-error" : null} type="text" name="mobile" id="mobile" placeholder="enter your mobile" onChange={handleChange} onBlur={handleBlur} value={values.mobile}></input>
                            <ErrorMessage className="errorcls" name="mobile" component="div"></ErrorMessage>
                        </div>
                        <div>
                            <label>Term</label> 
                            <input type="checkbox" name="term" id="term" onChange={handleChange} onBlur={handleBlur} value={values.term}></input>
                            <ErrorMessage className="errorcls" name="term" component="div"></ErrorMessage>
                        </div>
                        <div>
                            <button type="submit" disabled={isSubmitting}>submit</button>
                        </div>
                    </form>
                )}
            </Formik>
        </div>
    )
}
export default FomicForm
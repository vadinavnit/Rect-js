import React from 'react'

export const myContext = React.createContext();

export const Provider = myContext.Provider;
export const Consumer = myContext.Consumer;
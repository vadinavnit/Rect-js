import React, { Component } from 'react';


const HocEx = (RHOC) =>
{
    
class Hoc extends Component {
    state = {
        gunshot : 0
    }
    handleGunshot = () =>
    {
         this.setState({gunshot: this.state.gunshot + 1});
    }
    render() {
        return (
           <RHOC hocname="AK47" hocgunshot = {this.state.gunshot} hocHandleGunshot={this.handleGunshot}/>
        );
    }
}
    return Hoc;
}

export default HocEx;
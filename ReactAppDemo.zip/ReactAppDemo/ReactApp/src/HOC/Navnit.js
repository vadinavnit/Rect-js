import React, { Component } from 'react';
import Ghansyam from './Ghansyam';
import HocEx from './Hoc';

class Navnit extends Component {
    render() {
        return (
            <div>
            <h4 onMouseOver={this.props.hocHandleGunshot} >Gun : {this.props.hocname} Navnit Fire Gun  : {this.props.hocgunshot}</h4>
            <Ghansyam />
            </div>
        );
    }
}
export default HocEx(Navnit)
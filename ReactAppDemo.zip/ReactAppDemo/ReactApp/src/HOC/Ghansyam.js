import React, { Component } from 'react';
import HocEx from './Hoc';

class Ghansyam extends Component {

    render() {
        return (
            <div>
            <h4 onMouseOver={this.props.hocHandleGunshot} >Gun : {this.props.hocname} Ghansyam Fire Gun  : {this.props.hocgunshot}</h4>
            </div>
        );
    }
}
export default HocEx(Ghansyam);
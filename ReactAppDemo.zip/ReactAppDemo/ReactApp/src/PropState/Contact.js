import React from 'react';
import About from './About';
function Contact(props) {
    
      return (
        <div>
        <p>Contact Component</p>
        <About name={props.name} />
        </div>
      );
  }
  export default  Contact



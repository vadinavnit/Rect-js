import React from 'react';
export default function About(props) {
    
      return (
          <div>
          <p>About Component</p>
          <p>my name is {props.name}</p>
        </div>
        
      );
  }

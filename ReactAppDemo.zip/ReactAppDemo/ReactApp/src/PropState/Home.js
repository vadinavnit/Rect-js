import React from 'react';
import Contact from './Contact';
export default function Home(props) {

let name = 'Navnit'

      return (
        <div>
        <p>Home Component</p>
        <Contact name={name} />
        </div>
      );
  }

﻿using System.Collections.Generic;

    public class GenericRecordList<T> :GenericClass
    {
        public List<T> RecordList { get; set; }
        public GenericRecordList()
        {
            RecordList = new List<T>();
        }
    }

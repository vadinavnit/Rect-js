﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OOZEEAdmin.Common
{
    public  class Appsetting
    {
        public string Secret { get; set; } = "INVISIBLECHARACTERfe14593dd66b2406c5269d742d04b6e1ab03adb1";
    }
}

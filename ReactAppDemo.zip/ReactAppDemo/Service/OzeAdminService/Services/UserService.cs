﻿using System;
using System.Linq;

using OOZEEAdmin.EF;
using OOZEEAdmin.Common;
using System.Web;
using System.IO;
using System.Web.Security;
using System.Data;
using System.Drawing;
using System.Collections.Generic;
using OOZEEAdmin.EF.CustomClasses;
using System.Threading;
using System.Net.Http;
using System.Net;
using System.Configuration;
using System.Data.Entity;
using System.Net.Mail;
using System.Net.Mime;
using System.Data.OleDb;
using System.Threading.Tasks;
using System.Web.Configuration;

namespace OzeAdminService.Services
{
    public class UserService : CConnect
    {
        public GenericClass InsertUpdateContact(CInsertUpdateContact Data)
        {
            //Random rand = new Random();

            GenericClass Obj = new GenericClass();
            try
            {

                M_Contact MC = null;

                if(Data.ID == 0)
                {
                    MC = new M_Contact();
                }
                else
                {
                    MC = DC.M_Contact.Where(x => x.ID == Data.ID).FirstOrDefault();
                }

                MC.Name = Data.Name;
                MC.LastName = Data.LastName;
                MC.Subject = Data.Subject;
                MC.Country = Data.Country;

                if (Data.ID == 0)
                {
                    DC.M_Contact.Add(MC);
                }
                DC.SaveChanges();

                Obj.ReturnCode = ResponseMessages.SuccessCode;
                Obj.ReturnMsg = ResponseMessages.SuccessMsg;

            }
            catch (System.Exception ex)
            {

                throw;
            }
            return Obj;

        }

        public GenericClass ContactGetData(CContactGetData Data)
        {
            //Random rand = new Random();

            GenericClass Obj = new GenericClass();
            try
            {
                var _list = (from o in DC.M_Contact
                            select new
                            {
                                firstname = o.Name,
                                lastname = o.LastName,
                                country = o.Country,
                                subject = o.Subject,
                                Rowindex = o.ID
                            }).ToList();
                Obj.Data = _list;
                Obj.ReturnCode = ResponseMessages.SuccessCode;
                Obj.ReturnMsg = ResponseMessages.SuccessMsg;


            }
            catch (System.Exception ex)
            {

                throw;
            }
            return Obj;

        }


        public GenericClass DeleteContact(CContactDeleteData Data)
        {
            //Random rand = new Random();
            GenericClass Obj = new GenericClass();
            try
            {
                M_Contact MC = null;
                MC = DC.M_Contact.Where(x => x.ID == Data.ID).FirstOrDefault();
                DC.M_Contact.Remove(MC);
                DC.SaveChanges();

                Obj.ReturnCode = ResponseMessages.SuccessCode;
                Obj.ReturnMsg = ResponseMessages.SuccessMsg;

            }
            catch (System.Exception ex)
            {
                throw;
            }
            return Obj;
        }
 
        public async Task<GenericClass> Login(CLogin data)
        {
            //Random rand = new Random();
            GenericClass Obj = new GenericClass();
            try
            {
                CLoginResponse Response = new CLoginResponse();
                M_User MU = null;
                MU = await DC.M_User.Where(x => x.UserName == data.UserName && x.Password == data.Password).FirstOrDefaultAsync();

                if (MU == null)
                {
                    Obj.ReturnCode = ResponseMessages.AuthenticationFailedCode;
                    Obj.ReturnMsg = ResponseMessages.AuthenticationFailedMsg;
                }
                else
                {
                    Response.UserName = MU.UserName;
                    Response.FullName = MU.FullName;
                    Obj.Data = Response;
                    Obj.ReturnCode = ResponseMessages.SuccessCode;
                    Obj.ReturnMsg = ResponseMessages.SuccessMsg;
                }
            }
            catch (System.Exception ex)
            {
                throw;
            }
            return Obj;
        }
    }

}

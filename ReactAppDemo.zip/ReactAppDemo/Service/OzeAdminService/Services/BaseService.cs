﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OOZEEAdmin.Common;
using OOZEEAdmin.EF;

using System.Net.Mail;
using System.Web;
using System.Net.NetworkInformation;
using Newtonsoft.Json;
namespace OOZEEAdmin.Service.Services
{

    public class BaseService
    {
        private ReactAPIEntities DC = new ReactAPIEntities();

        string TOKEN = "123";

        public bool ValidateAPIToken(string APIKey, string JData, string MethodName)
        {
            //if (MethodName != "" && JData != "")
            //    ServiceLogException(null, MethodName, JData);
            bool _IsValid = false;
            try
            {
                if (TOKEN != APIKey)
                {
                    _IsValid = false;
                }
                else
                {
                    _IsValid = true;
                }
            }
            catch (System.Exception ex)
            {
                _IsValid = false;
            }
            return _IsValid;
        }


        public string ConvertJsontoString(object Data)
        {
            string result = JsonConvert.SerializeObject(Data);
            return result;
        }

        //public void ServiceLogException(System.Exception ex, string MethodName, string Data)
        //{
        //    try
        //    {
        //        EF.AppException _Exception = new EF.AppException();
        //        _Exception.UserID = null;
        //        _Exception.Method = MethodName;
        //        _Exception.Page = "";
        //        _Exception.Line = ex == null ? "0" : Convert.ToString(new System.Diagnostics.StackTrace(ex, true).GetFrame(0).GetFileLineNumber());
        //        _Exception.Object = Data;
        //        _Exception.Message = ex == null ? null : ex.Message;
        //        _Exception.CreatedDate = System.DateTime.UtcNow;
        //        _Exception.ExceptionType = 2;
        //        _Exception.IsSolved = false;
        //        DC.AppExceptions.Add(_Exception);
        //        DC.SaveChanges();
        //    }
        //    catch
        //    {
        //    }
        //}

        public string GetMachineID()
        {
            try
            {
                string MachineID = string.Empty;
                foreach (NetworkInterface nic in NetworkInterface.GetAllNetworkInterfaces())
                {

                    if (nic.OperationalStatus == OperationalStatus.Up && (!nic.Description.Contains("Virtual") && !nic.Description.Contains("Pseudo")))
                    {
                        if (nic.GetPhysicalAddress().ToString() != "")
                        {
                            MachineID = nic.GetPhysicalAddress().ToString();
                        }
                    }
                }
                return MachineID;
            }
            catch (System.Exception ex)
            {
                throw ex;
            }
        }

        public string CalculateTimeDifference(DateTime Post)
        {
            DateTime startTime = DateTime.Now.ToUniversalTime();
            string time = "";

            if (startTime.Date.Equals(ToClientDateTimeZone(Post).Value.Date))
            {
                TimeSpan span = startTime.Subtract(Post);

                if (span.Days >= 0)
                {
                    if (span.Hours == 0)
                    {
                        if (span.Minutes == 0)
                        {
                            time = span.Seconds.ToString() + " seconds ago";
                        }
                        else
                        {
                            time = span.Minutes.ToString() + " minutes ago";
                        }
                    }
                    else
                    {
                        time = span.Hours.ToString() + " hours ago";
                    }
                }
                else
                {
                    time = Post.ToString("dd MMMM,yyyy HH:mm");
                }
            }
            else
            {
                time = Post.ToString("dd MMMM,yyyy HH:mm");
            }
            return time;
        }

        public DateTime? ToClientDateTimeZone(DateTime? dt)
        {
            if (dt.HasValue)
            {
                // read the value from session
                var timeOffSet = "";// HttpContext.Current.Session["timezoneoffset"];

                if (timeOffSet != null)
                {
                    var offset = int.Parse(timeOffSet.ToString());
                    dt = dt.Value.AddMinutes(-1 * offset);
                    return dt;
                }
                // if there is no offset in session return the datetime in server timezone
                return dt.Value.ToLocalTime();
            }
            else
            {
                return dt;
            }
        }



    }
}

﻿using OOZEEAdmin.EF;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OzeAdminService.Services
{
    public class CConnect
    {
        public ReactAPIEntities DC;
        public CConnect()
        {
            DC = new ReactAPIEntities();
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OzeAdminService.Services
{
    public class CInsertUpdateContact
    {
        public string Token { get; set; }
        public Int32 ID { get; set; }
        public string Name { get; set; }
        public string LastName { get; set; }
        public string Country { get; set; }
        public string Subject { get; set; }
    }

    public class CContactGetData
    {
        public string Token { get; set; }
    }

    public class CContactDeleteData
    {
        public string Token { get; set; }
        public Int32 ID { get; set; }

    }
    public class CLogin
    {
        public string Token { get; set; }
        public string UserName { get; set; }

        public string Password { get; set; }

    }

}

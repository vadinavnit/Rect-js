﻿using OOZEEAdmin.EF;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace OzeAdminService.Services
{
    public class CLoginResponse
    {
        public string UserName { get; set; }
        public string FullName { get; set; }
        public string Token { get; set; }
    }


}


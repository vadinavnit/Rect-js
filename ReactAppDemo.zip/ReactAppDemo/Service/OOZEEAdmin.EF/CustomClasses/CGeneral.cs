﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.IO;
using System.Linq;
using System.Net.Mail;
using System.Runtime.Serialization.Json;
using System.Text;
using System.Threading.Tasks;

namespace OOZEEAdmin.EF.CustomClasses
{
    public enum DateInterval
    {
        Day,
        DayOfYear,
        Hour,
        Minute,
        Month,
        Quarter,
        Second,
        Weekday,
        WeekOfYear,
        Year
    }
    public class CGeneral
    {
        public static int FetchRecord = 25;
        public static string ConvertObjectToJSon<T>(T obj)
        {
            DataContractJsonSerializer ser = new DataContractJsonSerializer(typeof(T));
            MemoryStream ms = new MemoryStream();
            ser.WriteObject(ms, obj);
            string jsonString = Encoding.UTF8.GetString(ms.ToArray());
            ms.Close();
            return jsonString;
        }
        public static string GetDate(DateTime? Date = null)
        {
            if (Date != null)
            {
                return Date.Value.Day + "/" + Date.Value.Month + "/" + Date.Value.Year;
            }
            else
            {
                return "";
            }
        }
        public static long DateDiff(DateInterval intervalType, System.DateTime dateOne, System.DateTime dateTwo)
        {
            //dateOne =Convert.ToDateTime( "08/11/2016 6:33:56 AM");

            //dateTwo = System.DateTime.UtcNow;
          
            switch (intervalType)
            {
                case DateInterval.Day:
                case DateInterval.DayOfYear:
                    System.TimeSpan spanForDays = dateTwo - dateOne;
                    return (long)spanForDays.TotalDays;
                case DateInterval.Hour:
                    System.TimeSpan spanForHours = dateTwo - dateOne;
                    return (long)spanForHours.TotalHours;
                case DateInterval.Minute:
                    System.TimeSpan spanForMinutes = dateTwo - dateOne;
                    return (long)spanForMinutes.TotalMinutes;
                case DateInterval.Month:
                    return ((dateTwo.Year - dateOne.Year) * 12) + (dateTwo.Month - dateOne.Month);
                case DateInterval.Quarter:
                    long dateOneQuarter = (long)System.Math.Ceiling(dateOne.Month / 3.0);
                    long dateTwoQuarter = (long)System.Math.Ceiling(dateTwo.Month / 3.0);
                    return (4 * (dateTwo.Year - dateOne.Year)) + dateTwoQuarter - dateOneQuarter;
                case DateInterval.Second:
                    System.TimeSpan spanForSeconds = dateTwo - dateOne;
                    return (long)spanForSeconds.TotalSeconds;
                case DateInterval.Weekday:
                    System.TimeSpan spanForWeekdays = dateTwo - dateOne;
                    return (long)(spanForWeekdays.TotalDays / 7.0);
                case DateInterval.WeekOfYear:
                    System.DateTime dateOneModified = dateOne;
                    System.DateTime dateTwoModified = dateTwo;
                    while (dateTwoModified.DayOfWeek != System.Globalization.DateTimeFormatInfo.CurrentInfo.FirstDayOfWeek)
                    {
                        dateTwoModified = dateTwoModified.AddDays(-1);
                    }
                    while (dateOneModified.DayOfWeek != System.Globalization.DateTimeFormatInfo.CurrentInfo.FirstDayOfWeek)
                    {
                        dateOneModified = dateOneModified.AddDays(-1);
                    }
                    System.TimeSpan spanForWeekOfYear = dateTwoModified - dateOneModified;
                    return (long)(spanForWeekOfYear.TotalDays / 7.0);
                case DateInterval.Year:
                    return dateTwo.Year - dateOne.Year;
                default:
                    return 0;
            }
        }
        public static string ToDiffDateTimeZone(string date)
        {
            //DateTime dateOne = Convert.ToDateTime("08/12/2016 6:33:56 AM");
            DateTime CreatedDate = System.DateTime.UtcNow;
            Int64 val = 0;
            try
            {
                string Ago = string.Empty;
                if (string.IsNullOrEmpty(date))
                {
                    return "";
                }
                else
                {
                    DateTime dateOne = Convert.ToDateTime(date);
                    System.TimeSpan SP = CreatedDate - dateOne;
                    if (SP.TotalMinutes >= 60)
                    {
                        if (SP.TotalHours <= 24)
                        {
                            val = DateDiff(DateInterval.Hour, dateOne, CreatedDate);
                            Ago = val + " hour ago";
                        }
                        else
                        {
                            if (SP.TotalDays <= 7)
                            {
                                val = DateDiff(DateInterval.Day, dateOne, CreatedDate);
                                Ago = val + " day ago";
                            }
                            else
                            {
                                if (SP.TotalDays > 7)
                                {
                                    if (SP.TotalDays <= 30)
                                    {
                                        val = DateDiff(DateInterval.WeekOfYear, dateOne, CreatedDate);
                                        if (val == 0)
                                        {
                                            Ago = "1 week ago";
                                        }
                                        else
                                            Ago = val + " week ago";
                                    }
                                    else
                                    {
                                        double d = SP.TotalDays / 30;
                                        Ago = Math.Floor(d).ToString() + " month ago";
                                    }
                                }
                            }
                        }

                    }
                    else
                    {
                        if (SP.TotalMinutes <= 60)
                        {
                            val = DateDiff(DateInterval.Minute, dateOne, CreatedDate);

                            if (val <= 2)
                                Ago = " Just Now";
                            else
                                Ago = val + " m ago";



                            //Ago = "Just Now";

                        }
                        else
                        {
                            val = DateDiff(DateInterval.Second, dateOne, CreatedDate);
                            //Ago = val + " Seconds Ago";
                            Ago = " Just Now";

                        }
                    }
                }
                return Ago;
            }
            catch (Exception ex)
            {
                return "";
            }
        }
        public static DateTime ConvertDDMMYYYYtoYYYYMMDD(string Date)
        {
            try
            {

                string[] d = Date.Split('/');
                DateTime FinalDate = Convert.ToDateTime(d[2] + "/" + d[1] + "/" + d[0]);
                return FinalDate;
            }
            catch
            {
                return Convert.ToDateTime(Date);
            }
        }
        public static string DateFormatHandling(DateTime dt)
        {
            return string.Format("{0:MMM d, yyyy}", dt);
        }
        public static int GenerateRandomNo()
        {
            int _min = 1000;
            int _max = 9999;
            Random _rdm = new Random();
            return _rdm.Next(_min, _max);
        }
        public static bool SendMail(string Subject, string Body, string ToAddress)
        {
            bool IsEmailSend = false;

            try
            {

                string SenderEmailAddress = ConfigurationManager.AppSettings["SenderEmailAddress"].ToString();
                string SenderPassword = ConfigurationManager.AppSettings["SenderPassword"].ToString();
                string PortNumber = ConfigurationManager.AppSettings["PortNumber"].ToString();
                string SenderHostName = ConfigurationManager.AppSettings["SenderHostName"].ToString();
                bool EnableSSL = Convert.ToBoolean(ConfigurationManager.AppSettings["EnableSSL"].ToString());
                // Check All settings are True or Not
                System.Net.Mail.MailMessage objMail = new System.Net.Mail.MailMessage();

                objMail.From = new MailAddress(SenderEmailAddress);
                objMail.To.Add(new MailAddress(ToAddress));
                objMail.CC.Add(new MailAddress(SenderEmailAddress));
                objMail.Subject = Subject;
                objMail.Body = Body;
                objMail.Priority = System.Net.Mail.MailPriority.High;

                SmtpClient SMTPClientObj = new SmtpClient();
                SMTPClientObj.Credentials = new System.Net.NetworkCredential(SenderEmailAddress, SenderPassword);
                SMTPClientObj.Host = SenderHostName;
                SMTPClientObj.Port = Convert.ToInt32(PortNumber);
                SMTPClientObj.EnableSsl = EnableSSL;
                SMTPClientObj.Send(objMail);

                IsEmailSend = true;

            }
            catch (System.Exception ex)
            {
                IsEmailSend = false;
                throw ex;
            }
            return IsEmailSend;
        }
        public static string GetHostURL(string Path, string AbsolutePath)
        {
            try
            {
                if (!string.IsNullOrEmpty(AbsolutePath))
                {
                    
                        string Domain = ConfigurationManager.AppSettings["ImageDomain"].ToString();
                        //if (File.Exists(Path))
                            Path = Domain + AbsolutePath.Replace("~/", "/");
                        //else
                        //    Path = "";
                    
                }
                else
                    Path = "";

            }
            catch
            {
                Path = "";
            }
            return Path;
        }
    }
}

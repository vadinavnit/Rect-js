﻿using System;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;
using System.Threading.Tasks;
using System.Web.Http;
using Microsoft.IdentityModel.Tokens;
using OOZEEAdmin.Common;
using OOZEEAdmin.Service.Services;
using OzeAdminService.Services;

namespace OOZEEMVCWebAPI2.Controllers
{
    public class UserController : ApiController
    {
        public BaseService _BaseService = new BaseService();
        private readonly UserService _Service = new UserService();
        private Appsetting _appSettings = new Appsetting();

        [Route("InsertUpdateContact")]
        [HttpPost]

        
        public GenericClass InsertUpdateContact(CInsertUpdateContact data)
        {
            var Obj = new GenericClass();
            try
            {
                if (data == null)
                {
                    Obj.ReturnCode = ResponseMessages.NoDataCode;
                    Obj.ReturnMsg = "Please enter valid data";
                    Obj.ReturnValue = string.Empty;
                    return Obj;
                }
                Obj = _Service.InsertUpdateContact(data);
            }
            catch (Exception ex)
            {
                Obj.ReturnCode = ResponseMessages.ErrorCode;
                Obj.ReturnMsg = ResponseMessages.ErrorMsg;
                Obj.ReturnValue = string.Empty;
            }
            return Obj;
        }
        [Route("ContactGetData")]
        [HttpPost]
        public GenericClass ContactGetData(CContactGetData data)
        {
            var Obj = new GenericClass();
            try
            {
                if (data == null)
                {
                    Obj.ReturnCode = ResponseMessages.NoDataCode;
                    Obj.ReturnMsg = "Please enter valid data";
                    Obj.ReturnValue = string.Empty;
                    return Obj;
                }
                Obj = _Service.ContactGetData(data);
            }
            catch (Exception ex)
            {
                Obj.ReturnCode = ResponseMessages.ErrorCode;
                Obj.ReturnMsg = ResponseMessages.ErrorMsg;
                Obj.ReturnValue = string.Empty;
            }
            return Obj;
        }
        [Route("DeleteContact")]
        [HttpPost]
        public GenericClass DeleteContact(CContactDeleteData data)
        {
            var Obj = new GenericClass();
            try
            {
                if (data == null)
                {
                    Obj.ReturnCode = ResponseMessages.NoDataCode;
                    Obj.ReturnMsg = "Please enter valid data";
                    Obj.ReturnValue = string.Empty;
                    return Obj;
                }
                Obj = _Service.DeleteContact(data);
            }
            catch (Exception ex)
            {
                Obj.ReturnCode = ResponseMessages.ErrorCode;
                Obj.ReturnMsg = ResponseMessages.ErrorMsg;
                Obj.ReturnValue = string.Empty;
            }
            return Obj;
        }
        [Route("Login")]
        [HttpPost]
        public async Task<GenericClass> Login(CLogin data)
        {
            var Obj = new GenericClass();
            try
            {
                if (data == null)
                {
                    Obj.ReturnCode = ResponseMessages.NoDataCode;
                    Obj.ReturnMsg = "Please enter valid data";
                    Obj.ReturnValue = string.Empty;
                    return Obj;
                }
                Obj = await _Service.Login(data);
                var tokenHandler = new JwtSecurityTokenHandler();
                var key = Encoding.ASCII.GetBytes(_appSettings.Secret);
                var tokenDescriptor = new SecurityTokenDescriptor
                {
                    Subject = new ClaimsIdentity(new[]
                    {
                        new Claim(ClaimTypes.Name, Convert.ToString(data.UserName))
                    }),
                    Expires = DateTime.UtcNow.AddDays(7),
                    SigningCredentials = new SigningCredentials(new SymmetricSecurityKey(key),
                        SecurityAlgorithms.HmacSha256Signature)
                };
                var token = tokenHandler.CreateToken(tokenDescriptor);
                Obj.ReturnValue = tokenHandler.WriteToken(token); ;
            }
            catch (Exception ex)
            {
                Obj.ReturnCode = ResponseMessages.ErrorCode;
                Obj.ReturnMsg = ResponseMessages.ErrorMsg;
                Obj.ReturnValue = string.Empty;

            }
            return Obj;
        }
    }
}